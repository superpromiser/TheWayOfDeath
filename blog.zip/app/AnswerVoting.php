<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnswerVoting extends Model
{
    //
    protected $guarded = [];
}
