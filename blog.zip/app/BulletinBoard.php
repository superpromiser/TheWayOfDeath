<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class BulletinBoard extends Model
{
    //

    protected $guarded = [];
}
