<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestionnaireTemp extends Model
{
    //
    protected $guarded = [];
}
