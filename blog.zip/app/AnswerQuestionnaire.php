<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnswerQuestionnaire extends Model
{
    //
    protected $guarded = [];
}
