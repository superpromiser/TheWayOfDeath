<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anouncement extends Model
{
    //
    protected $guarded = [];
}
