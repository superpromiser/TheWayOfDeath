<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeVisit extends Model
{
    //
    protected $guarded = [];
}
