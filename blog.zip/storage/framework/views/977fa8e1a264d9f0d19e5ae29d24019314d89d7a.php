<?php
$config = [
    'appName' => config('app.name'),
    'locale' => $locale = app()->getLocale(),
    'locales' => config('app.locales'),
    'githubAuth' => config('services.github.client_id'),
    // 'csrfToken' => csrf_token(),
];
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <title><?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(mix('dist/css/all.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(mix('dist/css/app.css')); ?>">
  <script src="<?php echo e(asset('asset/js/jquery-3.5.1.min.js')); ?>"></script>
  <script>
    (function(){
      window.Laravel = {
        csrfToken:'<?php echo e(csrf_token()); ?>',
        base_url:"<?php echo e(URL::to('/')); ?>"
      }
    })();
  </script>
</head>
<body>
  <div id="app"></div>

  
  <script>
    window.config = <?php echo json_encode($config, 15, 512) ?>;
  </script>
  
  
  <script src="<?php echo e(mix('dist/js/app.js')); ?>"></script>
  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/spa.blade.php ENDPATH**/ ?>