import Vue from 'vue';
Vue.component('InfiniteLoading', require('vue-infinite-loading'));