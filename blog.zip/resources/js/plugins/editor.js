import Vue from 'vue'
import Editor from 'vue-editor-js'

Vue.use(Editor)