import Vue from 'vue';
import VueQrcode from '@chenfengyuan/vue-qrcode';
 
Vue.component(VueQrcode.name, VueQrcode);