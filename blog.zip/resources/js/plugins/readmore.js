import Vue from 'vue';
import ReadMore from 'vue-read-more';
 
Vue.use(ReadMore);