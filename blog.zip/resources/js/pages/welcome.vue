<template>
  <v-container fluid class="login-bg d-flex justify-center align-center">
    <v-row class="justify-center align-center">
      <v-col cols="12" lg="4" class="align-center">
        <p class="text-left white--text">教育是什么，往简单方面说，只需一句话，就是养成良好的习惯。</p>
        <p class="text-right white--text">——布鲁纳（教育家）</p>
      </v-col>
      <v-col cols="12" lg="4">
        <v-row class="justify-center">
          <v-col md="7" sm="12" xs="12">
            <v-card>
              <v-tabs
                v-model="tab"
                background-color="light-blue accent-4"
                centered
                dark
                icons-and-text
              >
                <v-tabs-slider></v-tabs-slider>
                <v-tab href="#qr-login">
                  扫码登录
                  <v-icon>mdi-qrcode</v-icon>
                </v-tab>
                <v-tab href="#phone-login">
                  账户登录
                  <v-icon>mdi-account</v-icon>
                </v-tab>
              </v-tabs>
              <v-tabs-items v-model="tab">
                <v-tab-item value='qr-login' >
                  <v-card flat class="pb-8 d-flex justify-center">
                    <qrcode value="http://47.111.233.60" :options="{ width: 350 }"></qrcode>
                  </v-card>
                </v-tab-item>
                
                <v-tab-item value='phone-login' >
                  <v-card flat>
                    <v-card-text ref="form">
                      <v-form v-model="isFormValid" @submit.prevent="login">
                        <v-text-field
                          v-model="phoneNumber"
                          label="帐号"
                          prepend-inner-icon="mdi-phone"
                          :rules="[rules.required]"
                          :counter="11"
                        ></v-text-field>
                        <v-text-field
                          v-model="password"
                          name="password"
                          label="密码"
                          hint="至少8个字符"
                          counter
                          prepend-inner-icon="mdi-key-chain-variant"
                          :rules="[rules.required, rules.min]"
                          :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                          :type="show1 ? 'text' : 'password'"
                          @click:append="show1 = !show1"
                        ></v-text-field>
                        <v-checkbox
                          v-model="agreeTerms"
                          label="已阅读并同意《用户服务协议》和《隐私》"
                          type="checkbox"
                          :rules="[rules.required]"
                        >
                          <template v-slot:label>
                            <div @click.stop="">
                              已阅读并同意
                              <a
                                href="#"
                                @click.prevent="terms = true"
                              >《用户服务协议》</a>
                              和
                              <a
                                href="#"
                                @click.prevent="conditions = true"
                              >《隐私》</a>
                            </div>
                          </template>
                        </v-checkbox>
                        <v-btn color="primary" block type="submit" :loading="isLogging" :disabled="!isFormValid">
                          <v-icon left>
                            mdi-login
                          </v-icon> 
                          登录
                        </v-btn>
                      </v-form>
                      <v-row class="justify-end pa-3">
                        <v-btn color="primary" text class="align-right">
                          忘记密码?
                        </v-btn>
                      </v-row>
                      <v-row class="justify-center align-center ">
                        <span>—————</span>
                        <span class="px-2">  使用第三方账号登录  </span>
                        <span>—————</span>
                      </v-row>
                      <v-row class="justify-center align-center pt-1 pb-4">
                        <v-btn color="primary" text>
                          <v-icon left>
                            mdi-wechat
                          </v-icon> 
                          企业微信
                        </v-btn>
                      </v-row>
                      <v-dialog v-model="terms" width="70%" >
                        <v-card>
                          <v-card-title class="title">
                            Terms
                          </v-card-title>
                          <v-card-text
                            v-for="n in 5"
                            :key="n"
                          >
                            {{ content }}
                          </v-card-text>
                          <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="terms = false"
                            >
                              Ok
                            </v-btn>
                          </v-card-actions>
                        </v-card>
                      </v-dialog>
                      <v-dialog
                        v-model="conditions"
                        width="70%"
                      >
                        <v-card>
                          <v-card-title class="title">
                            Conditions
                          </v-card-title>
                          <v-card-text
                            v-for="n in 5"
                            :key="n"
                          >
                            {{ content }}
                          </v-card-text>
                          <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                              text
                              color="primary"
                              @click="conditions = false"
                            >
                              Ok
                            </v-btn>
                          </v-card-actions>
                        </v-card>
                      </v-dialog>
                    </v-card-text>
                  </v-card>
                </v-tab-item>
              </v-tabs-items>
            </v-card>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
    <v-snackbar
      timeout="3000"
      v-model="loginFailed"
      color="error"
      absolute
      top
    >
      Login Failed
    </v-snackbar>
  </v-container>
</template>

<script>

import { mapGetters } from 'vuex';
import { loginApi } from '~/api/auth';

export default {
  middleware: 'guest',
  layout: 'basic',

  metaInfo () {
    return { title: this.$t('home') }
  },

  data: () => ({
    tab : 'phone-login',
    phoneNumber : '',
    password : '',
    show1 : false,
    agreeTerms : true,
    remember : false,
    rules : {
      required: value => !!value || '必需的。',
      min: v => v.length >= 8 || '最少8个字符',
    },
    isLogging : false,
    isFormValid : false,
    terms : false,
    conditions : false,
    loginFailed : false,
    schoolData : {},
    schoolTree : [],
    chooseableSchoolTree : [],
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa. Vestibulum lacinia arcu eget nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur sodales ligula in libero. Sed dignissim lacinia nunc.',

  }),

  computed: {
    ...mapGetters({
      authenticated: 'auth/check'
    })
  },

  methods: {
    async login(){
      this.isLogging = true;
      let payload = {
        phoneNumber : this.phoneNumber,
        password : this.password
      };
      await loginApi(payload)
        .then(res=>{
          this.isLogging = false;
          // Save the token.
          this.$store.dispatch('auth/saveToken', {
            token: res.data.token,
            remember: this.remember
          })
          console.log("!!!!!",res.data)
          // Fetch the user.
          this.$store.dispatch('auth/saveUserState', res.data.user)

          //save schoolTree
          if(res.data.user.schoolId !== 0){
            res.data.schoolTree.map( x => {
              if (x.id == res.data.user.schoolId){
                this.schoolData = x;
              }
            } )
            this.schoolData.grades.map ( grade => {
              let gradeObj = {
                  header : grade.gradeName,
                }
                this.schoolTree.push(gradeObj)
                grade.lessons.map( lesson => {
                  let lessonObj = {
                    lessonId : lesson.id,
                    gradeId : grade.id,
                    lessonName : lesson.lessonName,
                  }
                  this.schoolTree.push(lessonObj)
                } )
                let dividerObj = {
                  divider : true
                }
                this.schoolTree.push(dividerObj)
            })

            this.$store.dispatch('schooltree/storeSchoolTree', this.schoolTree);
            this.$store.dispatch('schooltree/storeSchoolData', this.schoolData);

            //make chooseable schoolTree
            this.schoolData.grades.map( grade => {
              let gradeObj = {
                id : grade.id,
                name : grade.gradeName,
                children : []
              }
              grade.lessons.map( lesson => {
                let lessonObj = {
                  id : lesson.id,
                  name : lesson.lessonName
                }
                gradeObj.children.push(lessonObj);
              } )
              this.chooseableSchoolTree.push(gradeObj);
            } )
            this.$store.dispatch('schooltree/storeChooseableSchoolTree', this.chooseableSchoolTree);
          }
          else{
            console.log("123123123", res.data.schoolTree);
            this.$store.dispatch('schooltree/storeSchoolData', res.data.schoolTree);
            res.data.schoolTree.map(schoolData=>{
              this.schoolData = schoolData
              this.schoolData.grades.map ( grade => {
              let gradeObj = {
                  header : grade.gradeName,
                }
                this.schoolTree.push(gradeObj)
                grade.lessons.map( lesson => {
                  let lessonObj = {
                    lessonId : lesson.id,
                    gradeId : grade.id,
                    lessonName : lesson.lessonName,
                  }
                  this.schoolTree.push(lessonObj)
                } )
                let dividerObj = {
                  divider : true
                }
                this.schoolTree.push(dividerObj)
            })

            this.$store.dispatch('schooltree/storeSchoolTree', this.schoolTree);
            //make chooseable schoolTree
            this.schoolData.grades.map( grade => {
              let gradeObj = {
                id : grade.id,
                name : grade.gradeName,
                children : []
              }
              grade.lessons.map( lesson => {
                let lessonObj = {
                  id : lesson.id,
                  name : lesson.lessonName
                }
                gradeObj.children.push(lessonObj);
              } )
              this.chooseableSchoolTree.push(gradeObj);
            } )
            this.$store.dispatch('schooltree/storeChooseableSchoolTree', this.chooseableSchoolTree);
            })
          }

          //save MemberData
          if( res.data.memberData !== null && (res.data.user.roleId == 3 || res.data.user.roleId == 4 || res.data.user.roleId == 5) ) {
            this.$store.dispatch('schooltree/storeMemberData', res.data.memberData);
          }
          
          // Redirect home.
          this.$router.push({ name: 'home' })
        })
        .catch(err=>{
          console.log(err);
          this.isLogging = false;
          this.loginFailed = true;
        })
    }
  },
}
</script>

<style scoped>
.top-right {
  position: absolute;
  right: 10px;
  top: 18px;
}

.title {
  font-size: 85px;
}
</style>
